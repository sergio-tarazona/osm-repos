import base64
import json
import os
import sys
import traceback

import requests
from charmhelpers.core.hookenv import (
    action_fail,
    action_set,
    action_get,
    config,
    status_set
)
from charms.reactive import (
    clear_flag,
    set_flag,
    when,
    when_not,
)


@when_not('paloalto-api-client.installed')
def install_paloalto_api_client():
    # Do your setup here.
    #
    # If your charm has other dependencies before it can install,
    # add those as @when() clauses above., or as additional @when()
    # decorated handlers below
    #
    # See the following for information about reactive charms:
    #
    #  * https://jujucharms.com/docs/devel/developer-getting-started
    #  * https://github.com/juju-solutions/layer-basic#overview
    #
    set_flag('paloalto-api-client.installed')


@when('actions.get-configuration')
def get_configuration():
    try:
        ip = action_get('sol002-hostname')
        key = action_get('sol002-key')

        url = 'https://%s/api/?type=config&action=set&key=%s&xpath=/config/devices/entry[@name=localhost.localdomain]/devceconfig' % (ip, key)

        #token = action_get('token')
        #cert = action_get('cert')
        #key = action_get('key')

        #with open('client.crt', 'x') as crt_file:
        #    crt_file.write(base64.b64decode(cert).decode('UTF-8'))

        #with open('client.key', 'x') as key_file:
        #    key_file.write(base64.b64decode(key).decode('UTF-8'))

        #result = requests.get(url, verify=False, cert=('client.crt', 'client.key'),
        #                      headers={"Authorization": "Bearer " + token})

        result = requests.get(url, verify=False)

        with open('/tmp/paloalto-api-client.log', 'a') as log_file:
            log_file.write(str(result.status_code))
            log_file.write(result.text)

        if result.status_code > 250:
            result.raise_for_status()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        err = traceback.format_exception(exc_type, exc_value, exc_traceback)
        action_fail('Getting vnf-configuration failed: ' + str(err))
    else:
        action_set({'output': result.text})
    finally:
        clear_flag('actions.get-configuration')
        status_set('active', 'ready!')

@when('actions.patch-configuration')
def patch_configuration():
    try:
        ip = action_get('sol002-hostname')
        key = action_get('sol002-key')
        data = action_get('vnfc-configuration-data') 

        url = 'https://%s/api/?type=config&action=set&key=%s&xpath=/config/devices/entry[@name=localhost.localdomain]/devceconfig/system&element=%s' % (ip, key, data)


        result = requests.get(url, verify=False)

        with open('/tmp/paloalto-api-client.log', 'a') as log_file:
            log_file.write(str(result.status_code))
            log_file.write(result.text)

        if result.status_code > 250:
            result.raise_for_status()
    except:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        err = traceback.format_exception(exc_type, exc_value, exc_traceback)
        action_fail('Patching vnf-configuration failed: ' + str(err))
    else:
        action_set({'output': result.text})
    finally:
        clear_flag('actions.patch-configuration')
        status_set('active', 'ready!')


# Sets the status of the charm to show in OSM: configured
@when('config.changed')
def config_changed():
    set_flag('paloalto-api-client.configured')
    status_set('active', 'ready!')
    return
